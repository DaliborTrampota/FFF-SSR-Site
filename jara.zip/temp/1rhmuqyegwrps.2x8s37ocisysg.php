<?php foreach ((\Flash::instance()->getMessages()?:[]) as $msg): ?>
  <div class="alert alert-<?= ($msg['status']) ?> alert-dismissible fade show" role="alert">
    <?= ($this->esc($msg['text']))."
" ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endforeach; ?>