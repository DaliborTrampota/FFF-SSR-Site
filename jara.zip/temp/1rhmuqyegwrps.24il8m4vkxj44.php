<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= (isset($title)?$title:'') ?></title>

    <!-- Boostrap CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- Boostrap JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

    <script src="https://kit.fontawesome.com/2a7fbc46b4.js" crossorigin="anonymous"></script> <!-- Font a icona na soubory -->

    <!-- JQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous">

    <script src="/assets/js/soubory.js"></script> <!-- JavaScript pro soubory-->

    <link rel="stylesheet" href="/assets/css/soubory.css"> <!-- CSS pro soubory-->
    <link rel="stylesheet" href="/assets/css/menu.css"> <!-- CSS pro menu-->
    <link rel="stylesheet" href="/assets/css/clanky.css"> <!-- CSS pro články-->
    <link rel="stylesheet" href="/assets/css/uzivatel.css"> <!-- CSS pro uživatele-->
    <link rel="stylesheet" href="/assets/css/hlavni-strana.css"> <!-- CSS na hlavní stránku-->
    <link rel="stylesheet" href="/assets/css/role.css"> <!-- CSS pro role-->
    <link rel="stylesheet" href="/assets/css/admin-panel.css"> <!-- CSS pro admin panel-->
    <link rel="stylesheet" href="/assets/css/akce.css"> <!-- CSS pro akce-->


    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

    <!-- Bootstrap Font Icon CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

</head>
<body>
