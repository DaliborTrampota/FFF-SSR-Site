<link rel="stylesheet" href="/assets/css/dark-mode.css">
<input type="checkbox"  class="hidden" id="darkSwitch" >
<label class="globe-icon" for="darkSwitch">🌓</label>
<script src="/assets/js/dark-mode-switch.min.js"></script>