

<form action="/login" method="post">
    <input type="text" name="email" required placeholder="Email">
    <input type="password" name="heslo" required placeholder="Heslo">
    <br>
    <button type="submit" class="bg-blue-500 px-3 py-1 font-bold text-xl my-2">Přihlásit</button>
    <button type="button" onclick="window.location.href = '/register'" class="px-3 py-1 text-md my-2">Registrovat se místo</button>
</form>