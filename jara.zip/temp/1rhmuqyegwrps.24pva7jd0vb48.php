<h1>Přihlášky na tábor</h1>
<div>20.7. - 4.8. 2025</div>
<button onclick="location.href='/prihlasit'" class="bg-blue-500 px-3 py-1 font-bold text-xl my-2">Přihlásit</button>